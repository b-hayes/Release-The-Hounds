﻿using UnityEngine;
using System.Collections;

public class MovingLight : MonoBehaviour {

	public float flicker = 1; //ammount to move the light by each frame
	public float range = 1; //range to keep light within (change direction if out of range)
	private float xd; //direction to move on x axis
	private float yd; //direction to move on y axis
	private float zd; //direction to move on z axis

	// Use this for initialization
	void Start () {
		//pick starting direction randomly
		xd = direction ();
		yd = direction ();
		zd = direction ();
	}
	
	// Update is called once per frame
	void Update () {
		//if light is out of its range on any axis change that axis direction of movement
		if (outOfRange (this.transform.position.x))
			xd = xd * -1;
		if (outOfRange (this.transform.position.y))
			yd = yd * -1;
		if (outOfRange (this.transform.position.z))
			zd = zd * -1;

		//shift the light
		this.transform.Translate (flicker*xd,flicker*yd,flicker*zd);

	}

	int direction(){
		//picks randomly -1 or 1
		int[] choices = {-1,1};
		return choices [Random.Range (0, 1)];
	}

	bool outOfRange(float Axis){
		if (Axis > range || Axis < (range * -1)) {
			return true;
		} else {
			return false;
		}
	}
}
