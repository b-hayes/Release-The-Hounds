﻿using UnityEngine;
using System.Collections;

public class Flickering_light : MonoBehaviour {
	
	public float MaxIntensity = 1; //range to keep light within (change direction if out of range)
	public float MinIntensity = 0.25f;
	public float Speed = 0.5f;
	private Light lt;

	// Use this for initialization
	void Start () {
		lt = this.GetComponent<Light> ();
	}
	
	// Update is called once per frame
	void Update () {
		lt.intensity = Random.Range (MinIntensity, MaxIntensity);
	}

}
